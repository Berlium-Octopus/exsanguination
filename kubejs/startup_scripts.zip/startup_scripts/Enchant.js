// priority: 200
const EnchantmentCategory = Java.loadClass('net.minecraft.world.item.enchantment.EnchantmentCategory');

StartupEvents.registry('enchantment', event => {
    event.create('exsanguination:awakening')
        .minLevel(1)
        .maxLevel(1)
        .category(EnchantmentCategory.ARMOR)
        .displayName('Awakening')
        .rarity('UNCOMMON')
});

StartupEvents.registry("enchantment", event => {
    event.create("exsanguination:golden_awakening")
        .minLevel(1)
        .maxLevel(1)
        .category(EnchantmentCategory.BREAKABLE)
        .displayName("Awakening")
})

//Liopyu's Cheese For Sculk Smitez I am forever grateful for your scrips
ForgeEvents.onEvent("net.minecraftforge.event.entity.living.LivingHurtEvent", event => global.hurt(event))
/**
 *
 * @param {Internal.LivingHurtEvent} event
 */

let listSculk = [
    'sculkhorde:sculk_enderman',
    'sculkhorde:sculk_spore_spewer',
    'sculkhorde:sculk_mite',
    'sculkhorde:sculk_sheep',
    'sculkhorde:sculk_mite_aggressor',
    'sculkhorde:sculk_bee_harvester',
    'sculkhorde:sculk_bee_infector',
    'sculkhorde:sculk_creeper',
    'sculkhorde:sculk_hatcher',
    'sculkhorde:sculk_ravager',
    'sculkhorde:sculk_spitter',
    'sculkhorde:sculk_vindicator',
    'sculkhorde:sculk_zombie',
    'sculkhorde:sculk_phantom',
    'sculkhorde:sculk_phantom_corpse',
    'sculkhorde:sculk_salmon',
    'sculkhorde:sculk_squid',
    'sculkhorde:sculk_pufferfish',
    'sculkhorde:sculk_witch',
    'sculkhorde:sculk_soul_reaper',
    'sculkhorde:sculk_vex',
    'alexsmobs:skreecher',
    'dummmmmmy:target_dummy'
]
let listHumanoid = [
    'alexsmobs:farseer',
    'minecraft:witch',
    'alexscaves:licowitch',
    'minecraft:villager',
    'minecraft:player',
    'minecraft:enderman',
    'whiteenderman:white_enderman',
    'guardvillagers:guard',
    'minecraft:ravager',
    'minecraft:piglin',
    'minecraft:piglin_brute',
    'luminous_nether:cultist_archer',
    'luminous_nether:piglin_cultist',
    'luminous_nether:piglin_cultist_leader',
    'luminous_beasts:piglin_executioner',
    'luminous_beasts:piglin_executioner',
    'sculkhorde:sculk_enderman',
    'dummmmmmy:target_dummy'
]
let projectilesource = [
    "jeg.bullet.killed",
    "jeg.bullet.eliminated",
    "jeg.bullet.annihilated",
    "jeg.bullet.executed",
    "gumball",
    "stalagmite",
    "supplementaries:cannonball",
    "createbigcannons.shrapnel",
    "createbigcannons.cannon_projectile",
    "createbigcannons.big_cannon_projectile",
    "createbigcannons.machine_gun_fire",
    "createbigcannons.machine_gun_fire_in_water",
    "createbigcannons.flak",
    "createbigcannons.grapeshot",
    "jeg.bullet.decimated",
    "falling_anvil",
    "create.run_over",
    "fireworks",
    "sonic_boom",
    "quark.pickarang",
    "supplementaries.cannonball.player"
  ]
let bulletsources = [
    "jeg.bullet.killed",
    "jeg.bullet.eliminated",
    "jeg.bullet.annihilated",
    "jeg.bullet.executed",
    "jeg.bullet.decimated"

]
// "All Technology Is Magic" - Kurt Vonni
let magician = [
    "indirectMagic",
    "desolate_dagger",
    "will_o_wisp",
    "raygun",
    "cataclysm.maledictio_magicae",
    "cataclysm.deathlaser",
    "supplementaries.xp_extracting",
    "spirit_dinosaur",
    "lightningBolt",
    "soulBullet",
    "cataclysm.maledictio",
    "cataclysm.maledictio_anima",
    "cataclysm.abyssal_burn",
    "outOfWorld",
    "dragon_breath",
    "farseer"
    // farseer
]
let wiltednerf = ["onFire"]
let doubledamage = ["explosion", "explosion.player"]
let animalBlacklist = ['minecraft:iron_golem','vinery:wandering_winemaker', 'minecraft:wandering_trader', 'minecraft:villager', 'minecraft:allay', 'guardvillagers:guard']
let animalWhitelist = ['minecraft:hoglin', 'luminous_beasts:rare_sea_viper', 'luminous_beasts:sea_viper', 'luminous_beasts:rare_yeti', 'luminous_beasts:yeti', 'luminous_beasts:rare_phoenix_bird', 'luminous_beasts:baby_phoenix', 'alexsmobs:sunbird', 'luminous_beasts:rare_vile_gator', 'luminous_beasts:vile_gator', 'alexscaves:vesper', 'alexscaves:underzealot', 'alexscaves:corrodent']
let rabies = ['rabial_end','drown']
// Based Of vomiter's Script
EntityJSEvents.attributes(event => {event.allTypes.forEach(type => {
    event.modify(type, ctx => {
        ctx.add("alexscavesexemplified:rabies_resistance")
    })
})})

EntityJSEvents.attributes(event => {event.allTypes.forEach(type => {
    event.modify(type, ctx => {
        ctx.add("biomemakeover:projectile_resistance")
    })
})})

EntityJSEvents.attributes(event => {event.allTypes.forEach(type => {
    event.modify(type, ctx => {
        ctx.add("potioncore:magic_shield")
    })
})})

const getrabiesNegationLvl = (source, entity) => {
    const $ResourceKey = Java.loadClass("net.minecraft.resources.ResourceKey")
    const $TagKey = Java.loadClass("net.minecraft.tags.TagKey")
    if(!rabies.includes(source.getType())) return;
    const rabiesNegation = entity.getAttribute("alexscavesexemplified:rabies_resistance")
    if(!rabiesNegation) return;
    const rabiesNegationLvl = rabiesNegation.getValue()
    return rabiesNegationLvl
}

ForgeEvents.onEvent("net.minecraftforge.event.entity.living.LivingHurtEvent", event => global.RabiesNegation$LivingHurtEvent(event))
global.RabiesNegation$LivingHurtEvent = (event) => {
    const {source, amount, entity} = event
    const rabiesNegationLvl = getrabiesNegationLvl(source, entity)
    if(!rabiesNegationLvl) return;
    if(rabiesNegationLvl >= 20) event.setCanceled(true)
    event.setAmount(amount * (20 - rabiesNegationLvl) / 20)
}

const getprojectileNegationLvl = (source, entity) => {
    const $ResourceKey = Java.loadClass("net.minecraft.resources.ResourceKey")
    const $TagKey = Java.loadClass("net.minecraft.tags.TagKey")
    if(!projectilesource.includes(source.getType())) return;
    const projectileNegation = entity.getAttribute("biomemakeover:projectile_resistance")
    if(!projectileNegation) return;
    const projectileNegationLvl = projectileNegation.getValue()
    return projectileNegationLvl
}

ForgeEvents.onEvent("net.minecraftforge.event.entity.living.LivingHurtEvent", event => global.projectileNegation$LivingHurtEvent(event))
global.projectileNegation$LivingHurtEvent = (event) => {
    const {source, amount, entity} = event
    const projectileNegationLvl = getprojectileNegationLvl(source, entity)
    if(!projectileNegationLvl) return;
    if(projectileNegationLvl >= 20) event.setCanceled(true)
    event.setAmount(amount * (20 - projectileNegationLvl) / 20)
}

const getmagicNegationLvl = (source, entity) => {
    const $ResourceKey = Java.loadClass("net.minecraft.resources.ResourceKey")
    const $TagKey = Java.loadClass("net.minecraft.tags.TagKey")
    if(!projectilesource.includes(source.getType())) return;
    const magicNegation = entity.getAttribute("potioncore:magic_shield")
    if(!magicNegation) return;
    const magicNegationLvl = magicNegation.getValue()
    return magicNegationLvl
}

ForgeEvents.onEvent("net.minecraftforge.event.entity.living.LivingHurtEvent", event => global.magicNegation$LivingHurtEvent(event))
global.magicNegation$LivingHurtEvent = (event) => {
    const {source, amount, entity} = event
    const magicNegationLvl = getmagicNegationLvl(source, entity)
    if(!magicNegationLvl) return;
    if(magicNegationLvl >= 20) event.setCanceled(true)
    event.setAmount(amount * (20 - magicNegationLvl) / 20)
}

global.hurt = event => {
    // Sculk Script
    let {entity,source,amount} = event
    let attacker = source.actual
/*
    if (entity.isAlive()) {
      Utils.server.runCommandSilent(`say ${source}`)
      Utils.server.runCommandSilent(`say ${amount}`)
    }
*/
    if (projectilesource.includes(source.getType())) {
        var unbreak = 0
        let armorPieces = [
            entity.getHeadArmorItem(),
            entity.getChestArmorItem(),
            entity.getLegsArmorItem(),
            entity.getFeetArmorItem()
        ].forEach((piece) => {
            if (piece.id != "minecraft:air") {
                unbreak += piece.getEnchantments().get('minecraft:projectile_protection')
            }
        })
        if (unbreak > 0) {
            let reduction = unbreak * 0.08
            let finalDamage = amount * (1 - reduction)
            event.setAmount(finalDamage)
            Utils.server.runCommandSilent(`say ${amount}`)
        }
    }

    // Magician But Weaker for magic protection effect 0.08 to 0.08
    if (magician.includes(source.getType())) {
        var unbreak = 0
        let armorPieces = [
            entity.getHeadArmorItem(),
            entity.getChestArmorItem(),
            entity.getLegsArmorItem(),
            entity.getFeetArmorItem()
        ].forEach((piece) => {
            if (piece.id != "minecraft:air") {
                unbreak += piece.getEnchantments().get('minecraft:magic_protection')
            }
        })
        if (unbreak > 0) {
            let reduction = unbreak * 0.08
            let finalDamage = amount * (1 - reduction)
            event.setAmount(finalDamage)
        }
    }
/* Fix This Later IDK
            if (wiltednerf.includes(source.getType())) {
                var unbreak = 0
                let armorPieces = [
                    entity.getHeadArmorItem(),
                    entity.getChestArmorItem(),
                    entity.getLegsArmorItem(),
                    entity.getFeetArmorItem()
                ].forEach((piece) => {
                  if (piece.id == ["rootoffear:wraithwood_boots",
                          "rootoffear:wraithwood_leggings",
                          "rootoffear:wraithwood_chestplate",
                          "rootoffear:wraithwood_helmet"]) {
                      unbreak += piece.id().get()
                    }
                })
                if (unbreak > 0) {
                    let reduction = unbreak * 99999
                    event.setAmount(99999)
                    Utils.server.runCommandSilent(`say ${amount}`)
                }
            }
*/

// Un-Broken Curruntly?
if (doubledamage.includes(source.getType())) {
  if (entity.type == "minecraft:player"){
  let boom = amount * 2
        event.setAmount((boom))
        }
}


    // Un-Broken Curruntly?
    if (bulletsources.includes(source.getType())) {
        if (!attacker) return
            let pazazz = (attacker.attributes.getValue("jeg:generic.gun_damage"));
            if (pazazz > 0){
            event.setAmount((amount * pazazz))
          //  attacker.tell("PAINPOWER: " + pazazz + ", DAMAGE: " + amount + ", FINALDAMAGE: " + (amount * pazazz))
            }
    }

    if (listSculk.toString().includes(entity.type)) { // This part is Xeru's script
        if (!attacker) return
        if (source.getType() != 'player') return
        let smiteLvl = attacker.mainHandItem.getEnchantmentLevel("deeperdarker:sculk_smite")
        if (attacker.mainHandItem.getEnchantmentLevel("deeperdarker:sculk_smite") > 0) {
            let smiteDamage = (0.5 + smiteLvl * 2.5);
            let Highnumber = (0.5 + smiteLvl);
            event.setAmount((amount + smiteDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("potioncore:broken_armor", Highnumber, 2, false, true)
            }
            attacker.tell("Smite damage: " + smiteDamage + ", original damage: " + amount + ", final damage: " + (amount + smiteDamage))
        }
        if (attacker.offHandItem.getEnchantmentLevel("deeperdarker:sculk_smite") > 0) {
            let smiteDamage = (0.5 + smiteLvl * 2.5);
            let Highnumber = (0.5 + smiteLvl);
            event.setAmount((amount + smiteDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("potioncore:broken_armor", Highnumber, 2, false, true)
            }
            //attacker.tell("Offhand Smite damage: " + smiteDamage + ", original damage: " + amount + ", final damage: " + (amount + smiteDamage))
        }

        // Error: dev.latvian.mods.rhino.EcmaError: TypeError: Cannot call method "getEnchantmentLevel" of undefined (startup_scripts:Enchant.js#232)
    }

    if (listHumanoid.toString().includes(entity.type)) {
        if (!attacker) return
        if (source.getType() != 'player') return
        let BaneLvl = attacker.mainHandItem.getEnchantmentLevel("extra_enchantments:illagers_bane")
        if (attacker.mainHandItem.getEnchantmentLevel("extra_enchantments:illagers_bane") > 0) {
            let baneDamage = (0.5 + BaneLvl * 2.5);
            let Highnumber = (0.5 + BaneLvl);
            event.setAmount((amount + baneDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("minecraft:weakness", Highnumber, 2, false, true)
            }
            attacker.tell("Builder Bane damage: " + baneDamage + ", original damage: " + amount + ", final damage: " + (amount + baneDamage))
        }
        if (attacker.offHandItem.getEnchantmentLevel("extra_enchantments:illagers_bane") > 0) {
            let baneDamage = (0.5 + BaneLvl * 2.5);
            let Highnumber = (0.5 + BaneLvl);
            event.setAmount((amount + baneDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("minecraft:weakness", Highnumber, 2, false, true)
            }
            //attacker.tell("Offhand Builder Bane damage: " + baneDamage + ", original damage: " + amount + ", final damage: " + (amount + baneDamage))
        }
    }
// HELP ME IT CRASHES WHAT
    if (entity.isAnimal()) {
        if (!attacker) return
        if (source.getType() != 'player') return
        let Greaterbane = attacker.mainHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods")
        if (attacker.mainHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods") > 0) {
            let baneDamage = (0.5 + Greaterbane * 2.5);
            let Highnumber = (0.5 + Greaterbane);
            event.setAmount((amount + baneDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("minecraft:slowness", Highnumber, 2, false, true)
            }
            //attacker.tell("Animal Bane damage: " + baneDamage + ", original damage: " + amount + ", final damage: " + (amount + baneDamage))
        }
        if (attacker.offHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods") > 0) {
            let baneDamage = (0.5 + Greaterbane * 2.5);
            let Highnumber = (0.5 + Greaterbane);
            event.setAmount((amount + baneDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("minecraft:slowness", Highnumber, 2, false, true)
            }
            //attacker.tell("Offhand Animal Bane damage: " + baneDamage + ", original damage: " + amount + ", final damage: " + (amount + baneDamage))
        }
    }

    // Thanks to my 1 IQ I could mitigate the animal damage yippie it weakens damage if it has hm forget it
    if (animalBlacklist.toString().includes(entity.type)) {
        if (!attacker) return
        if (source.getType() != 'player') return
        let BaneLvl2 = attacker.mainHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods")
        if (attacker.mainHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods") > 0) {
            let baneDamage2 = (0.5 + BaneLvl2 * 2.5);
            let baneDamage = (0.5 + BaneLvl2 * 2.5);
            event.setAmount((amount + baneDamage - baneDamage2))
            //      attacker.tell("Anti Animal Bane damage: " + baneDamage2 + ", original damage: " + (amount + baneDamage) + ", final damage: " + (amount + baneDamage - baneDamage2))
        }
        if (attacker.offHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods") > 0) {
            let baneDamage2 = (0.5 + BaneLvl2 * 2.5);
            let baneDamage = (0.5 + BaneLvl2 * 2.5);
            event.setAmount((amount + baneDamage - baneDamage2))
            //      attacker.tell("Offhand Anti Animal Bane damage: " + baneDamage2 + ", original damage: " + (amount + baneDamage) + ", final damage: " + (amount + baneDamage - baneDamage2))
        }
    }
    if (animalWhitelist.toString().includes(entity.type)) {
        if (!attacker) return
        if (source.getType() != 'player') return
        let BaneLvl3 = attacker.mainHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods")
        if (attacker.mainHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods") > 0) {
            let baneDamage = (0.5 + BaneLvl3 * 2.5);
            let Highnumber = (0.5 + BaneLvl3);
            event.setAmount((amount + baneDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("minecraft:slowness", Highnumber, 2, false, true)
            }
            //    attacker.tell("Anti Bane damage: " + baneDamage2 + ", original damage: " + amount + ", final damage: " + (amount + baneDamage2))
        }
        if (attacker.offHandItem.getEnchantmentLevel("minecraft:bane_of_arthropods") > 0) {
            let baneDamage = (0.5 + BaneLvl3 * 2.5);
            let Highnumber = (0.5 + BaneLvl3);
            event.setAmount((amount + baneDamage))
            if (Math.random() < 0.6) {
                entity.potionEffects.add("minecraft:slowness", Highnumber, 2, false, true)
            }
            //    attacker.tell("Offhand  Animal Bane damage: " + baneDamage2 + ", original damage: " + amount + ", final damage: " + (amount + baneDamage2))
        }

    }
    if (entity.isUndead()) {
        if (!attacker) return
        if (source.getType() != 'player') return
        let Smittens = attacker.mainHandItem.getEnchantmentLevel("minecraft:smite")
        if (attacker.mainHandItem.getEnchantmentLevel("minecraft:smite") > 0) {
            let Highnumber = (0.5 + Smittens);
            if (Math.random() < 0.6) {
                entity.potionEffects.add("potioncore:fire", Highnumber, 1, false, true)
            }
            //    attacker.tell("Anti Bane damage: " + baneDamage2 + ", original damage: " + amount + ", final damage: " + (amount + baneDamage2))
        }
        if (attacker.offHandItem.getEnchantmentLevel("minecraft:smite") > 0) {
            let Highnumber = (0.5 + Smittens);
            if (Math.random() < 0.6) {
                entity.potionEffects.add("potioncore:fire", Highnumber, 1, false, true)
            }
            //    attacker.tell("Offhand  Animal Bane damage: " + baneDamage2 + ", original damage: " + amount + ", final damage: " + (amount + baneDamage2))
        }

    }

}

StartupEvents.registry("enchantment", event => {
    event.create("minecraft:magic_protection")
        .minLevel(1)
        .maxLevel(4)
        .rarity('UNCOMMON')
        .category(EnchantmentCategory.ARMOR)
        .displayName("Magic Protection")
})

// If this works create Hemmorage protection (Blast+Ice Prot+Immunity to Hemmorage)
//         "create.crush",freeze, thirst   shotgun_explosion drown freddy  grave_cloud_suffocation cramming wither nuke  player_bomb_explosion crush,grave_cloud_suffocation,prickly_vines
// Buff Fire prot
// fan_lava,deathlaser,fireball,molten_lead,hyperthermia,stove_burn,,luminous_nether:furnace_damage,fan_fire,firework,stove_burn,abyssal_burn,lazer,volatile_scoria_explosion,boiling,molten_metal
