StartupEvents.registry('mob_effect', event => {
  event.create('exsanguination:dimentional_sickness') // Create the effect under "kubejs:custom_effect"
    .color(0xBE59E5) // Sets the color of the Effect's Particles.
    .harmful() // Categorizes the Effect as Beneficial.
})

StartupEvents.registry('mob_effect', event => {
  event.create('sculkhorde:mite_feast') // Create the effect under "kubejs:custom_effect"
    .color(0xBE59E5) // Sets the color of the Effect's Particles.
})


StartupEvents.registry('mob_effect', event => {
  event.create('exsanguination:unlisted') // Create the effect under "kubejs:custom_effect"
    .color(0xA1BF33) // Sets the color of the Effect's Particles.
    .harmful() // Categorizes the Effect as Beneficial.
				});


StartupEvents.registry('mob_effect', event => {
  event.create('exsanguination:reincarnatus') // Create the effect under "kubejs:custom_effect"
    .color(0xF8D7780) // Sets the color of the Effect's Particles.
    .beneficial() // Categorizes the Effect as Beneficial.
})

StartupEvents.registry("mob_effect", (event) => {
    event
        .create("alexsmobsinteraction:riftform") // Create the effect under "kubejs:custom_effect"
        .color(0xb2abdd) // Sets the color of the Effect's Particles.
        .beneficial() // Categorizes the Effect as Beneficial.
        .effectTick((entity, level) => {
            if (!entity || entity.level.isClientSide() || !entity.isPlayer()) return;
            entity.setGameMode("spectator");
            entity.server.scheduleInTicks(0, () => {
                if (!entity.potionEffects.isActive('alexsmobsinteraction:riftform')) {
                entity.setGameMode("survival");
                }
            });
        });
});
StartupEvents.registry('mob_effect', event => {
  event.create('rootoffear:courage')
    .modifyAttribute("forge:entity_reach", "6ce7cee7-13f1-45b2-bc5c-81d8a583a0cb", 1, 'addition')
    .color(0x312B19) // Sets the color of the Effect's Particles.
    .beneficial() // Categorizes the Effect as Beneficial.
})

// Liopyu
ForgeEvents.onEvent("net.minecraftforge.event.entity.ProjectileImpactEvent", event => global.onProjectileImpact(event))
/**
 *
 * @param {Internal.ProjectileImpactEvent} event
 */
global.onProjectileImpact = event => {
    let { projectile, impactResult, rayTraceResult } = event
    try {
        if (projectile.type == "alexscaves:limestone_spear") {
            if (rayTraceResult.type == "entity") {
                if (Math.random() >= 0.85)
                    projectile.kill()
            }
        }
            if (projectile.type == "alexscaves:frostmint_spear") {
                if (rayTraceResult.type == "entity") {
                    if (Math.random() >= 0.75)
                        projectile.kill()
                }
        }
    } catch (error) {
        console.log("Error in onProjectileImpact: ", error)
    }
}

ForgeEvents.onEvent('net.minecraftforge.event.entity.player.PlayerSleepInBedEvent', event => {
    global.onSleep(event)
})
global.onSleep = event => {
    const { entity, player } = event
    
    if (entity.level.dimension != "minecraft:overworld") return
    if (entity.type == "minecraft:player") return
 //   if (Math.random()<0.9 || entity.potionEffects.isActive('potioncore:curse')){
    entity.potionEffects.add("minecraft:slow_falling", 500, 0, false, true)
    entity.teleportTo("lostcities:lostcity", 0, 100, 0, entity.yaw, entity.pitch)
    entity.persistentData.put("inventoryData", entity.nbt.get("Inventory"))
    // entity.persistentData.put("CuriosData", entity.getCuriosInventory())
  //  }
}
    /*

ForgeEvents.onEvent('net.minecraftforge.event.entity.player.PlayerWakeUpEvent', event => {
    global.onWake(event)
})

global.onWake = event => {
    const { entity, player } = event
    
    if (entity.level.dimension != "minecraft:overworld") return
    if (entity.type == "minecraft:player") return
    if (Math.random()<0.9 || entity.potionEffects.isActive('potioncore:curse')){
    entity.potionEffects.add("minecraft:slow_falling", 900, 0, false, true)
    entity.teleportTo("lostcities:lostcity", 0, 100, 0, entity.yaw, entity.pitch)
    entity.persistentData.put("inventoryData", entity.nbt.get("Inventory"))
    entity.persistentData.put("CuriosData", entity.getCuriosInventory())
    }
}
    */

/*
java.lang.IllegalArgumentException: Cannot get property DirectionProperty{name=facing, clazz=class net.minecraft.core.Direction, values=[north, south, west, east]} as it does not exist in Block{minecraft:grass}
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.world.level.block.state.StateHolder.m_61143_(StateHolder.java:98)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.level.ServerPlayer.m_7720_(ServerPlayer.java:844)
	at TRANSFORMER/sleep_tight@1.20-1.4.7/net.mehvahdjukaar.sleep_tight.common.entities.BedEntity.startSleepingOn(BedEntity.java:394)
	at TRANSFORMER/sleep_tight@1.20-1.4.7/net.mehvahdjukaar.sleep_tight.common.entities.BedEntity.m_8119_(BedEntity.java:122)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.level.ServerLevel.m_8647_(ServerLevel.java:693)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.world.level.Level.mixinextras$bridge$accept$167(Level.java)
	at TRANSFORMER/neruina@3.2.1/com.bawnorton.neruina.handler.TickHandler.safelyTickEntities(TickHandler.java:113)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.world.level.Level.wrapOperation$dbn000$catchTickingEntities$notTheCauseOfTickLag(Level.java:9541)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.world.level.Level.m_46653_(Level.java:479)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.level.ServerLevel.m_184063_(ServerLevel.java:343)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.world.level.entity.EntityTickList.m_156910_(EntityTickList.java:54)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.level.ServerLevel.m_8793_(ServerLevel.java:323)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.MinecraftServer.m_5703_(MinecraftServer.java:893)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.MinecraftServer.m_5705_(MinecraftServer.java:814)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.client.server.IntegratedServer.m_5705_(IntegratedServer.java:89)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.MinecraftServer.m_130011_(MinecraftServer.java:661)
	at TRANSFORMER/minecraft@1.20.1/net.minecraft.server.MinecraftServer.m_206580_(MinecraftServer.java:251)
	at java.base/java.lang.Thread.run(Thread.java:840)

*/
//Modify Bedrock to be mineable, liopyu
BlockEvents.modification(event => {
    event.modify("minecraft:bedrock", block => {
        block.setDestroySpeed(5000)
    })
})
//Modify the break speed of bedrock
ForgeEvents.onEvent("net.minecraftforge.event.entity.player.PlayerEvent$BreakSpeed", event => {
    global.breakSpeed(event)
})

/**
 *
 * @param {Internal.PlayerEvent$BreakSpeed} event
 */
global.breakSpeed = event => {
    try {
        if (event.entity instanceof Java.loadClass("net.minecraft.world.entity.player.Player")) {
            if (event.entity.mainHandItem.id != "spelunkery:bedrock_buster") return
            if (event.state.block.id == "minecraft:bedrock") {
                event.setNewSpeed(25)
            }
        }

    } catch (error) {
        console.log(error)
    }
}

global.livingFallEvent = event => {}
ForgeEvents.onEvent("net.minecraftforge.event.entity.living.LivingFallEvent", event=>{
    global.livingFallEvent(event)
})


// Liopyu
/*
ForgeEvents.onEvent('net.minecraftforge.event.entity.living.LivingEvent$LivingTickEvent', event => {
    global.entitytick(event)
})
/**
 *
 * @param {Internal.LivingEvent$LivingTickEvent} event
 */
/*
global.entitytick = event => {
    const { entity } = event
    if (entity.type != 'sculkhorde:sculk_enderman') return
    if (entity.age % 40 != 0) return
    if (entity.inWaterOrRain) {
        entity.attack('generic', 15)
    }
}
*/

// HAHA WHITEMAN
EntityJSEvents.modifyEntity(event => {
    event.modify("whiteenderman:white_enderman", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=900
                let effectDuration2=40
                if (Math.random() > 0.4) {
                targetEntity.potionEffects.add("potioncore:random_teleport",effectDuration2,0,true,true)
                }
                targetEntity.potionEffects.add("exsanguination:dimentional_sickness",effectDuration,0,true,true)
        });
    });

    event.modify("minecraft:enderman", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=900
                let effectDuration2=20
                if (Math.random() > 0.8) {
                targetEntity.potionEffects.add("potioncore:random_teleport",effectDuration2,0,true,true)
                }
                targetEntity.potionEffects.add("exsanguination:dimentional_sickness",effectDuration,0,true,true)
        });
    });


    event.modify("minecraft:endermite", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=30
                if (Math.random() > 0.5) {
                targetEntity.potionEffects.add("exsanguination:dimentional_sickness",effectDuration,0,true,true)
                targetEntity.potionEffects.add("potioncore:random_teleport",effectDuration,0,true,true)
                }
        });
    });

    event.modify("sculkhorde:sculk_mite_aggressor", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=20
                if (Math.random() > 0.5) {
                targetEntity.potionEffects.add("exsanguination:dimentional_sickness",effectDuration,0,true,true)
                }
        });
    });

    event.modify("sculkhorde:sculk_mite", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=20
                if (Math.random() > 0.4) {
                targetEntity.potionEffects.add("exsanguination:dimentional_sickness",effectDuration,0,true,true)
                }
        });
    });

    event.modify("luminous_beasts:vile_gator", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=100
                if (Math.random() > 0.5) {
                targetEntity.potionEffects.add("alexscaves:irradiated",effectDuration,0,true,true)
                }
        });
    });

    event.modify("luminous_monsters:glacial_zombie", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=120
                targetEntity.potionEffects.add("toughasnails:internal_chill",effectDuration,0,true,true)
                if (Math.random() > 0.5) {
                targetEntity.potionEffects.add("alexsmobs:exsanguination",effectDuration,0,true,true)
                }
        });
    });
    event.modify("alexsmobs:froststalker", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=120
                targetEntity.potionEffects.add("toughasnails:internal_chill",effectDuration,0,true,true)
                if (Math.random() > 0.6) {
                targetEntity.potionEffects.add("alexsmobs:exsanguination",effectDuration,0,true,true)
                }
        });
    });

    event.modify("alexscaves:vallumraptor", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=120
                if (Math.random() > 0.7) {
                targetEntity.potionEffects.add("alexsmobs:exsanguination",effectDuration,0,true,true)
                }
        });
    });



    event.modify("luminous_monsters:swamp_zombie", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=120
                if (Math.random() > 0.9) {
                targetEntity.potionEffects.add("alexsmobs:oiled",effectDuration,1,true,true)
                }
        });
    });

    event.modify("luminous_nether:crimson_walker", modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=120
                if (Math.random() > 0.9) {
                targetEntity.potionEffects.add("toughasnails:internal_warmth",effectDuration,0,true,true)
                targetEntity.potionEffects.add("alexsmobs:exsanguination",effectDuration,0,true,true)
                }
        });
    });

    event.modify("sculkhorde:sculk_enderman", modifyBuilder => {
      modifyBuilder.onHurtTarget(context => {
          const {entity, targetEntity} = context
          let effectDuration=10
          let effectDuration2=220
          let effectDuration3=99999
          if (Math.random() > 0.8) {
            targetEntity.potionEffects.add("alexsmobs:fear",effectDuration,0,true,true)}
          if (Math.random() > 0.9) {
          targetEntity.potionEffects.add("potioncore:broken_armor",effectDuration2,3,true,true)}
          if (Math.random() > 0.9) {
          targetEntity.potionEffects.add("alexsmobsinteraction:skreeching",effectDuration3,0,true,true)}
          if (Math.random() > 0.75) {
          targetEntity.potionEffects.add("alexsmobsinteraction:farseer_icon",effectDuration,0,true,true)}
  });
    });

// Screech Your Last :)
    let sculk = [
    'deeperdarker:angler_fish',
    'deeperdarker:sculk_centipede',
    'deeperdarker:sculk_leech',
    'deeperdarker:sculk_snapper',
    'deeperdarker:shattered',
    'deeperdarker:shriek_worm',
    'deeperdarker:sludge',
    'deeperdarker:stalker',
    'minecraft:phantom',
    'minecraft:warden',
    'sculkhorde:sculk_creeper',
    'sculkhorde:sculk_enderman',
    'sculkhorde:sculk_hatcher',
    'sculkhorde:sculk_ravager',
    'sculkhorde:sculk_spitter',
    'sculkhorde:sculk_spore_spewer',
    'sculkhorde:sculk_vindicator',
    'sculkhorde:sculk_witch',
    'sculkhorde:sculk_soul_reaper']
    sculk.forEach(w => {
    event.modify(w, modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=10
                let effectDuration2=220
                let effectDuration3=99999
                if (Math.random() > 0.8) {
                  targetEntity.potionEffects.add("alexsmobs:fear",effectDuration,0,true,true)}
                if (Math.random() > 0.9) {
                targetEntity.potionEffects.add("potioncore:broken_armor",effectDuration2,4,true,true)}
                if (Math.random() > 0.99) {
                targetEntity.potionEffects.add("alexsmobsinteraction:skreeching",effectDuration3,0,true,true)}
        });
    });
    });

    let hemmoandesang = [
'alexscaves:atlatitan',
'alexscaves:grottoceratops',
'alexscaves:luxtructosaurus',
'alexscaves:relicheirus',
'alexscaves:tremorsaurus',
'minecraft:zoglin'
  ]
    hemmoandesang.forEach(e => {
    event.modify(e, modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=100
                if (Math.random() > 0.6) {
                    targetEntity.potionEffects.add("alexsmobs:exsanguination",effectDuration,1,true,true)
                    targetEntity.potionEffects.add("luminous_nether:hemorrhage",effectDuration,1,true,true)}
            });
            });
        });


    let undead = [
    'minecraft:zombie',
    'luminous_monsters:miner_zombie',
    'luminous_monsters:dark_oak_zombie',
    'luminous_monsters:savanna_zombie',
    'minecraft:zombified_piglin',
    'luminous_nether:piglin_ghost',
    'luminous_nether:ghost',
    'quark:wraith',
    'minecraft:zombie_villager',
    'minecraft:zombified_piglin',
  ]
    undead.forEach(e => {
    event.modify(e, modifyBuilder => {
            modifyBuilder.onHurtTarget(context => {
                const {entity, targetEntity} = context
                let effectDuration=93
                if (Math.random() > 0.85) {
                    targetEntity.potionEffects.add("alexsmobs:exsanguination",effectDuration,1,true,true)}
            });
            });
        });


        event.modify("minecraft:drowned", modifyBuilder => {
                modifyBuilder.onHurtTarget(context => {
                    const {entity, targetEntity} = context
                    let effectDuration=93
                    let effectDuration2=120
                    if (Math.random() > 0.7) {
                    targetEntity.potionEffects.add("alexsmobs:exsanguination",effectDuration,0,true,true)
                    }
                    if (Math.random() > 0.5) {
                    targetEntity.potionEffects.add("potioncore:drown",effectDuration2,0,true,true)
                    }
            });
        });


        let figherz = [
        'minecraft:piglin',
        'minecraft:piglin_brute',
        'luminous_nether:piglin_executioner',
        'luminous_nether:piglin_cultist',
        'luminous_nether:piglin_cultist_leader',
        'minecraft:vindicator'
      ]
        figherz.forEach(e => {
        event.modify(e, modifyBuilder => {
                modifyBuilder.onHurtTarget(context => {
                    const {entity, targetEntity} = context
                    let effectDuration=100
                    if (Math.random() > 0.85) {
                        targetEntity.potionEffects.add("potioncore:broken_armor",effectDuration,3,true,true)}
                })
                })
            })
})
