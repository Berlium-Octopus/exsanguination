// priority: 0
const $TierSortingRegistry = Java.loadClass("net.minecraftforge.common.TierSortingRegistry")
const $Tiers = Java.loadClass("net.minecraft.world.item.Tiers")
const $ForgeTier = Java.loadClass("net.minecraftforge.common.ForgeTier")
const $BlockTags = Java.loadClass("net.minecraft.tags.BlockTags")

StartupEvents.registry("item", (e) => {
    e.create("minecraft:copper_axe", "axe")
        .texture('kubejs:item/copper_axe')
        .tier("copper")
        .rarity("common")
        .displayName("Copper Axe");
});

StartupEvents.registry("item", (e) => {
    e.create("minecraft:copper_sword", "sword")
        .texture('kubejs:item/copper_sword')
        .tier("copper")
        .rarity("common")
        .displayName("Copper Sword");
});

StartupEvents.registry("item", (e) => {
    e.create("minecraft:copper_shovel", "shovel")
        .texture('kubejs:item/copper_shovel')
        .tier("copper")
        .rarity("common")
        .displayName("Copper Shovel");
});

StartupEvents.registry("item", (e) => {
    e.create("minecraft:copper_hoe", "hoe")
      .texture('kubejs:item/copper_hoe')
        .tier("copper")
        .rarity("common")
        .displayName("Copper Hoe");
});

StartupEvents.registry("item", (e) => {
    e.create("minecraft:copper_pickaxe", "pickaxe")
      .texture('kubejs:item/copper_pickaxe')
        .tier("copper")
        .rarity("common")
        .displayName("Copper Pickaxe");
});

StartupEvents.registry("item", (e) => {
    e.create("farmersdelight:copper_knife", "farmersdelight:knife")
      .texture('kubejs:item/copper_knife')
        .tier("copper")
        .rarity("common")
        .displayName("Copper Knife");
});


StartupEvents.registry("item", (e) => {
    e.create("farmersdelight:wooden_knife", "farmersdelight:knife")
      .texture('kubejs:item/wooden_knife')
        .tier("wooden")
        .rarity("common")
        .displayName("Wooden Knife")
        .attackDamageBaseline(-0.1);
});


  StartupEvents.registry('item', event => {
    event.create('spelunkery:bedrock_buster', 'pickaxe')
      .displayName("Bedrock Buster")
      .texture('kubejs:item/bedrock_buster')
      .rarity('UNCOMMON')
      .tier("bedrock_buster")
      })


    ItemEvents.toolTierRegistry((event) => {
        event.add("bedrock_buster", (tier) => {
            tier.level = 1
            tier.uses = 50
            tier.speed = 0.2
            tier.attackDamageBonus = 0.1
            tier.enchantmentValue = 3
            tier.repairIngredient = "minecraft:netherite_ingot"
        })
    })


ItemEvents.toolTierRegistry((event) => {
    event.add("copper", (tier) => {
        tier.level = -1
        tier.uses = 145
        tier.speed = 2.5
        tier.attackDamageBonus = 1.5
        tier.enchantmentValue = 20
        tier.repairIngredient = "#forge:ingots/copper"
    })
    const CopperTier = new $ForgeTier(0, 32, 12, 0, 22, $BlockTags.create("minecraft:needs_copper_tool"), () => Ingredient.of("#forge:ingots/copper"))
    $TierSortingRegistry.registerTier(CopperTier, "copper", [$Tiers.STONE], [$Tiers.IRON])
})

ItemEvents.modification(event => {
    event.modify("minecraft:copper_axe", item => {
        item.tier = $TierSortingRegistry.byName("copper")
    })
})

ItemEvents.modification(event => {
    event.modify("minecraft:copper_pickaxe", item => {
        item.tier = $TierSortingRegistry.byName("copper")
    })
})

ItemEvents.modification(event => {
    event.modify("minecraft:copper_sword", item => {
        item.tier = $TierSortingRegistry.byName("copper")
    })
})

ItemEvents.modification(event => {
    event.modify("minecraft:copper_shovel", item => {
        item.tier = $TierSortingRegistry.byName("copper")
    })
})

ItemEvents.modification(event => {
    event.modify("minecraft:copper_hoe", item => {
        item.tier = $TierSortingRegistry.byName("copper")
    })
})


ItemEvents.modification(event => {
    event.modify("farmersdelight:copper_knife", item => {
        item.tier = $TierSortingRegistry.byName("copper")
    })
})
